#imports
import time
import sys

#variaveis
calculadora = 1
relogio = 2
adefinir = 3
fechar = 4
opMenu = 0
#funçoes
def MenuTemporizado():
    print('Bem vindo ao seu programa de utilidades!')
    print('O que precisas?')
    time.sleep(1)    
    print ('''
    1 - Calculadora:
    2 - Relógio:
    3 - Fechar programa
    ''')
    print('\n')




#prints iniciais



#menu e chamado de arquivos externos

while True:
  MenuTemporizado()
  opMenu = int(input())
  if opMenu == 1:
    while (calculadora):
      print('\n')
      exec(open("calculadora.py").read())
      break
      
  elif opMenu == 2:
    while(relogio):
      print('\n')
      exec(open("relogio.py").read())
      break

  elif opMenu == 3:
    print('Fechando o programa')
    time.sleep(2)
    sys.exit('Programa encerrado')

  else:
    print('Opção inválida!', '\n')
    print('O programa será encerrado!')
    time.sleep(2)
    sys.exit('Programa encerrado')