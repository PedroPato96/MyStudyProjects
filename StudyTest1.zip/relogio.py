from datetime import datetime


now = datetime.now().time() # time object
print("Agora é ", now)
print('\n')